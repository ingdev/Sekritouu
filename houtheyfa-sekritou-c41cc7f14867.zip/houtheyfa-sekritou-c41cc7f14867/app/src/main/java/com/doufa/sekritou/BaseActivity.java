package com.doufa.sekritou;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.messaging.FirebaseMessaging;

public class BaseActivity extends AppCompatActivity {
    private static final String TAG = "BaseActivity";

    private ProgressDialog mProgressDialog;

    public void showProgressDialog() {

        if (mProgressDialog == null) {
            mProgressDialog = new ProgressDialog(this);
            mProgressDialog.setCancelable(false);
            mProgressDialog.setMessage("Loading...");
        }

        mProgressDialog.show();
    }

    public void hideProgressDialog() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.dismiss();
        }
    }


    public String getUid() {
        return FirebaseAuth.getInstance().getCurrentUser().getUid();
    }

    public void subscribeToTopic(String topic){
        // [START subscribe_topics]
        FirebaseMessaging.getInstance().subscribeToTopic(topic);
        // [END subscribe_topics]

        // Log and toast
        String msg = "Subscribed to"+ topic +"topic";
        Log.d(TAG, msg);
    }

    public boolean isValidString(String str){
        str = str.trim();
//        return str.matches("^([A-Za-z]+)(\\s[A-Za-z]+)*\\s?$");
        return TextUtils.isEmpty(str);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
