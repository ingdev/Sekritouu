package com.doufa.sekritou.posts.viewholder;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.doufa.sekritou.R;
import com.doufa.sekritou.posts.models.Post;
import com.doufa.sekritou.posts.utils.Utils;

public class PostViewHolder extends RecyclerView.ViewHolder {

    public TextView titleView;
    public TextView authorView;
    public ImageView starView;
    public TextView starCount;
    public TextView bodyView;
    public TextView posted_atView;
    public TextView commCount;

    Context context ;
    public PostViewHolder(View itemView) {
        super(itemView);

        titleView = (TextView) itemView.findViewById(R.id.post_title);
        authorView = (TextView) itemView.findViewById(R.id.post_author);
        starView = (ImageView) itemView.findViewById(R.id.post_like_icon);
        starCount = (TextView) itemView.findViewById(R.id.post_like_txt);

        commCount = (TextView) itemView.findViewById(R.id.post_comment_txt);
        bodyView = (TextView) itemView.findViewById(R.id.post_body);
        posted_atView = (TextView) itemView.findViewById(R.id.post_date);

        context = itemView.getContext();
    }

    public void bindToPost(Post post, View.OnClickListener starClickListener) {

        titleView.setText(post.title);
        authorView.setText(post.author);
//        starCount.setText(String.valueOf(post.starCount));
//        commCount.setText(String.valueOf(post.commCount));
        bodyView.setText(post.body);
        posted_atView.setText(Utils.CalPostTime(post.posted_at));
        starView.setOnClickListener(starClickListener);

        if(post.starCount == 0 ){
            starCount.setText("");
        } else if(post.starCount == 1){
            starCount.setText(String.valueOf(post.starCount));
//            starCount.setText(String.format(context.getString(R.string.post_like_text),post.starCount));
        }else{
            starCount.setText(String.valueOf(post.starCount));
//            starCount.setText(String.format(context.getString(R.string.post_likes_text),post.starCount));
        }

        if(post.commCount == 0){
            commCount.setText("");
        }else if(post.commCount == 1){
            commCount.setText(String.valueOf(post.commCount));
//            commCount.setText(String.format(context.getString(R.string.post_comment_text),  post.commCount));
        }else {
            commCount.setText(String.valueOf(post.commCount));
//            commCount.setText(String.format(context.getString(R.string.post_comments_text), post.commCount));
        }


    }


}
