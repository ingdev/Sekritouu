package com.doufa.sekritou.notif;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Intent;
import android.content.Context;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

import com.doufa.sekritou.R;
import com.doufa.sekritou.posts.PostDetailActivity;
import com.doufa.sekritou.posts.models.Comment;
import com.doufa.sekritou.posts.models.Post;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class IServicePushNotif extends IntentService {

    private String uid;

    private DatabaseReference mDatabase;

    public IServicePushNotif() {
        super("IServicePushNotif");
    }


    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            mDatabase = FirebaseDatabase.getInstance().getReference();
            newPostListener();
            newCommentListener();
        }
    }


   private void newPostListener () {
       mDatabase.child("posts").addChildEventListener(new ChildEventListener() {
           @Override
           public void onChildAdded(DataSnapshot dataSnapshot, String s) {
               String pkey = dataSnapshot.getKey();
               Post post = dataSnapshot.getValue(Post.class);
                 if (!uid.equals(post.uid))
                    pushNotif(pkey,"someone just posted a new secret!",post.body);
           }

           @Override
           public void onChildChanged(DataSnapshot dataSnapshot, String s) {}
           @Override
           public void onChildRemoved(DataSnapshot dataSnapshot) {}
           @Override
           public void onChildMoved(DataSnapshot dataSnapshot, String s) {}
           @Override
           public void onCancelled(DatabaseError databaseError) {}
       });

   }
    private void newCommentListener(){
        mDatabase.child("post-comments").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {}

            @Override
            public void onChildChanged(final DataSnapshot dataSnapshot, String s) {
               final String pkey = dataSnapshot.getKey();

                mDatabase.child("posts").child(pkey).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot data) {
                        Post post = data.getValue(Post.class);

                        if (post.uid.equals(uid)) {
                            Comment comm = dataSnapshot.getValue(Comment.class);
                            pushNotif(pkey,"Someone just commented on your secret!","");
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {}
                });
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {}
            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {}
            @Override
            public void onCancelled(DatabaseError databaseError) {}
        });

    }

    private void  pushNotif(String post_key, String subject, String body){

        Intent resultIntent = new Intent(getApplicationContext(),PostDetailActivity.class);
        resultIntent.putExtra("post_key",post_key);

//        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
//        stackBuilder.addParentStack(PostDetailActivity.class);
//        stackBuilder.addNextIntent(resultIntent);

        PendingIntent resultPendingIntent = PendingIntent.getActivity(this,0, resultIntent,PendingIntent.FLAG_ONE_SHOT);

        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(getApplicationContext())
                        .setContentTitle("Sekritou")
                        .setSubText(body)
                        .setContentText(subject)
                        .setSmallIcon(R.mipmap.ic_sekritou_icon)
                        .setContentIntent(resultPendingIntent)
                        .setAutoCancel(true);

        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.notify(0, mBuilder.build());
    }

/**
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // ...

        // TODO(developer): Handle FCM messages here.
        // Not getting messages here? See why this may be: https://goo.gl/39bRNJ
        Log.d(TAG, "From: " + remoteMessage.getFrom());

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());
        }

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
        }

        // Also if you intend on generating your own notifications as a result of a received FCM
        // message, here is where that should be initiated. See sendNotification method below.
    }
    **/


}
