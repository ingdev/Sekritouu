## Sekritoo :

Is a social Android application that permits to users to share their thoughts, secrets and stories anonymously.
